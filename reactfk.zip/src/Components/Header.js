// Header.jsx
import React from "react";
import Logo from "../Assets/Icons/logo.png"
import Add from "../Assets/Icons/add.png"
import Cart from "../Assets/Icons/shoppings.png"


const Header = () => {
  return (
    <header className="w-full shadow-sm">
      {/* Top Blue Header */}
      <div className="bg-[#2874F0] flex items-center justify-between pr-3 pt-3 pb-2">
        {/* Left */}
        <div className="flex items-center gap-1">
          
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-left w-10 h-5"><path d="m15 18-6-6 6-6"></path></svg>

            <img src={Logo} alt="" className="h-8" />
        </div>

        {/* Right Icons */}
        <div className="flex items-center gap-5">
          <img src={Add} alt="" className="h-[16px]" />
          <img src={Cart} alt="" className="h-[16px]" />

        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-[#2874F0] px-3 pb-2">
        <div className="bg-white h-10 rounded-sm flex items-center px-3 shadow-sm">

          <input
            type="text"
            placeholder="Search for Products, Brands and More"
            className="w-full outline-none text-[15px] placeholder:text-gray-500 bg-transparent"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;